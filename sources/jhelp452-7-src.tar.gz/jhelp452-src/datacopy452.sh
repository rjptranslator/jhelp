#!/usr/bin/bash.exe
export VER=4.5.2
for i in {base,compiler,datasets,graphics,grDevices,grid,methods,parallel,splines,stats,stats4,tcltk,tools,utils,boot,class,cluster,codetools,foreign,KernSmooth,lattice,MASS,Matrix,mgcv,nlme,nnet,rpart,spatial,survival}
do
    mkdir jhelp/inst/library/$i
    cp -R R-$VER/library/$i/help jhelp/inst/library/$i/
    cp -R R-$VER/library/$i/html jhelp/inst/library/$i/
    cp -R R-$VER/library/$i/Meta jhelp/inst/library/$i/
    cp R-$VER/library/$i/DESCRIPTION jhelp/inst/library/$i/
    cp R-$VER/library/$i/INDEX jhelp/inst/library/$i/
    if [ $i != base ]; then
	cp R-$VER/library/$i/NAMESPACE jhelp/inst/library/$i/
    fi
done

for i in {R-FAQ,R-admin,R-data,R-exts,R-intro,R-ints,R-lang,rw-FAQ}
do
    cp R-$VER/doc/manual/$i.html jhelp/inst/doc/manual/
    cp R-$VER/doc/manual/$i.pdf jhelp/inst/doc/manual/
done

cp -r R-$VER/doc/manual/images jhelp/inst/doc/manual/
