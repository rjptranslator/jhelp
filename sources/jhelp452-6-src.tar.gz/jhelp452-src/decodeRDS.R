decode_hex_string <- function(x) {
  vapply(x, function(elem) {
    if (is.na(elem) || !nzchar(elem)) return(elem)
    
    repeat {
      m <- regexpr("(<[0-9A-Fa-f]{2}>)+", elem)
      if (m[1] == -1) break
      
      block <- regmatches(elem, m)
      
      hex_vec <- unlist(regmatches(block, gregexpr("[0-9A-Fa-f]{2}", block)))
      nums <- suppressWarnings(strtoi(hex_vec, 16L))
      nums <- nums[!is.na(nums) & nums != 0]
      
      if (length(nums) == 0) {
        regmatches(elem, m) <- ""
      } else {
        decoded <- rawToChar(as.raw(nums))
        regmatches(elem, m) <- decoded
      }
    }
    
    elem
  }, character(1))
}

for(i in c("base","compiler","datasets","graphics","grDevices","grid","methods","parallel","splines","stats","stats4","tcltk","tools","utils")) {
  Rdfile <- readRDS(paste0(i, "/Meta/Rd.rds"))
  hsearchfile <- readRDS(paste0(i, "/Meta/hsearch.rds"))
  hsearchfile[[1]][, 5] <- Rdfile$Title <- decode_hex_string(Rdfile$Title)
  saveRDS(Rdfile, paste0(i, "/Meta/Rd.rds"))
  saveRDS(hsearchfile, paste0(i, "/Meta/hsearch.rds"))
}
