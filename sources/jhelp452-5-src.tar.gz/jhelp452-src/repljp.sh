#!/usr/bin/bash.exe
for i in *.tar.gz
do
    tar xzf $i
    DIR=`echo $i | sed 's/_.*//'`
    cp -R ../../../../jhelp452-src/Recommended/$DIR .
    find $DIR -type f ! -name MD5 -print0 | LC_ALL=C sort -z | xargs -0 md5sum | sed 's| \*\./| *|' > MD5
    sed "s+$DIR/++g" MD5 > $DIR/MD5
    tar czf $i $DIR
    rm -rf $DIR
done
rm MD5
